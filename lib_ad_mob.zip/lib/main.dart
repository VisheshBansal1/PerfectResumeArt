import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'core/constants/app_theme.dart';
import 'core/router/app_router.dart';
import 'core/services/ad_config.dart';
import 'core/services/app_config.dart';
import 'firebase_options.dart';
import 'providers/premium_access_providers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Config values come from --dart-define at build time (no .env file needed).
  // See AppConfig for all keys and build command documentation.
  AppConfig.validate();

  /// Initialize Firebase safely
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    // FIX 1: On web, explicitly set auth persistence to LOCAL so the browser
    // stores the session in IndexedDB and remembers the user across page reloads.
    // Without this, Firebase web defaults to session-only persistence.
    if (kIsWeb) {
      await FirebaseAuth.instance.setPersistence(Persistence.LOCAL);
    }
  } catch (e) {
    debugPrint('Firebase init error: $e');
  }

  // Rewarded-ad monetization — must be initialized once before any
  // RewardedAd.load() call. Web has no AdMob support, so this is a no-op
  // there (AdConfig.isSupported already excludes kIsWeb).
  if (AdConfig.isSupported) {
    await MobileAds.instance.initialize();
  }

  runApp(const ProviderScope(child: ResumeAnalyzerApp()));
}

class ResumeAnalyzerApp extends ConsumerWidget {
  const ResumeAnalyzerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Starts preloading a rewarded ad as soon as the app's widget tree
    // exists, so one is usually already warm by the time the premium
    // dialog's "Watch Ad" button is tapped. Riverpod caches this provider,
    // so watching it here doesn't re-trigger a load on every rebuild.
    ref.watch(rewardedAdServiceProvider);

    final router = ref.watch(appRouterProvider);

    return MaterialApp.router(
      title: 'Perfect Resume Art',

      debugShowCheckedModeBanner: false,

      theme: AppTheme.lightTheme,

      darkTheme: AppTheme.darkTheme,

      themeMode: ThemeMode.system,

      routerConfig: router,
    );
  }
}
