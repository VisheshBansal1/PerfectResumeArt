// lib/core/services/premium_service.dart
//
// Business logic for the hybrid monetization system. Widgets and screens
// should never read Firestore or call the unlock endpoint directly — they
// go through this class (or, more commonly, through PremiumGuard, which
// wraps it). See INTEGRATION_GUIDE.md for the full data flow.

import 'dart:async';
import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;

import '../../models/premium_status.dart';
import 'app_config.dart';
import 'firebase_service.dart';

enum PremiumUnlockErrorCode {
  notSignedIn,
  weeklyLimitReached,
  alreadyPremium,
  network,
  unknown,
}

class PremiumUnlockException implements Exception {
  final PremiumUnlockErrorCode code;
  final String message;
  const PremiumUnlockException({required this.code, required this.message});

  @override
  String toString() => message;
}

class PremiumService {
  PremiumService(this._firebaseService);

  final FirebaseService _firebaseService;

  String? get _uid => FirebaseAuth.instance.currentUser?.uid;

  Future<PremiumStatus> _fetchStatus() async {
    final uid = _uid;
    // Signed-out / guest — always reads as free with no access, never as
    // an error, so callers can use this in guest-accessible screens too.
    if (uid == null) return const PremiumStatus();
    return _firebaseService.getPremiumStatus(uid);
  }

  /// Live status stream — drives the countdown timer and weekly-token
  /// badge so they update the instant Firestore syncs the backend's write.
  Stream<PremiumStatus> statusStream() {
    final uid = _uid;
    if (uid == null) return Stream.value(const PremiumStatus());
    return _firebaseService.streamPremiumStatus(uid);
  }

  // ── Required PremiumService methods ───────────────────────────────────

  Future<bool> isPremium() async => (await _fetchStatus()).isPremiumActive;

  Future<bool> isRewardUnlocked() async =>
      (await _fetchStatus()).isRewardUnlockActive;

  Future<bool> canAccessPremium() async =>
      (await _fetchStatus()).canAccessPremium;

  Future<Duration> remainingUnlockTime() async =>
      (await _fetchStatus()).remainingUnlockTime;

  /// Weekly free unlocks left, applying the rolling 7-day reset (display
  /// only — see PremiumStatus for why this is safe to compute locally).
  Future<int> weeklyUnlocksRemaining() async =>
      (await _fetchStatus()).weeklyRemaining;

  /// Grants a temporary premium unlock. Call this ONLY after
  /// RewardedAdService.showRewardedAd() has returned `true` — i.e. AdMob's
  /// onUserEarnedReward actually fired. Never call this speculatively;
  /// the backend enforces the weekly cap regardless, but the UX should
  /// never let a user "spend" an ad-watch that didn't happen.
  ///
  /// Throws [PremiumUnlockException] — check `.code` to decide what to
  /// show (e.g. PremiumUnlockErrorCode.weeklyLimitReached gets the exact
  /// "Your weekly free unlock limit has been reached..." copy from the
  /// product spec; `.message` already contains it).
  Future<PremiumStatus> unlockPremiumTemporarily() async {
    final idToken = await FirebaseAuth.instance.currentUser?.getIdToken();
    if (idToken == null) {
      throw const PremiumUnlockException(
        code: PremiumUnlockErrorCode.notSignedIn,
        message: 'Please sign in to unlock premium features.',
      );
    }

    final backendUrl = AppConfig.backendUrl;
    if (backendUrl.isEmpty) {
      throw const PremiumUnlockException(
        code: PremiumUnlockErrorCode.network,
        message: 'Backend URL not configured.',
      );
    }

    http.Response response;
    try {
      response = await http
          .post(
            Uri.parse('$backendUrl/api/premium/unlock-reward'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $idToken',
            },
          )
          .timeout(const Duration(seconds: 20));
    } catch (_) {
      throw const PremiumUnlockException(
        code: PremiumUnlockErrorCode.network,
        message: 'No internet connection. Please try again.',
      );
    }

    Map<String, dynamic> body;
    try {
      body = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw PremiumUnlockException(
        code: PremiumUnlockErrorCode.unknown,
        message: 'Unexpected server response (${response.statusCode}).',
      );
    }

    if (response.statusCode == 200 && body['success'] == true) {
      // Build a status straight from the response for an instant UI
      // update — the Firestore stream will confirm it moments later.
      return PremiumStatus(
        isPremiumFlag: body['isPremium'] as bool? ?? false,
        rewardUnlockExpiry: _millisToDate(body['rewardUnlockExpiry']),
        weeklyRewardCount: body['weeklyRewardCount'] as int? ?? 0,
        lastRewardReset: DateTime.now(),
      );
    }

    final errorCode = body['code'] as String?;
    final errorMessage = body['error'] as String? ?? 'Could not grant unlock. Please try again.';

    if (response.statusCode == 403 && errorCode == 'WEEKLY_LIMIT_REACHED') {
      throw PremiumUnlockException(
        code: PremiumUnlockErrorCode.weeklyLimitReached,
        message: errorMessage,
      );
    }
    if (response.statusCode == 409 && errorCode == 'ALREADY_PREMIUM') {
      throw PremiumUnlockException(
        code: PremiumUnlockErrorCode.alreadyPremium,
        message: errorMessage,
      );
    }
    throw PremiumUnlockException(
      code: PremiumUnlockErrorCode.unknown,
      message: errorMessage,
    );
  }

  static DateTime? _millisToDate(dynamic value) {
    if (value == null) return null;
    if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
    if (value is num) return DateTime.fromMillisecondsSinceEpoch(value.toInt());
    return null;
  }
}
