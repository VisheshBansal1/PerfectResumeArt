// lib/core/services/ad_config.dart
//
// AdMob ad unit IDs, following the same --dart-define pattern as
// app_config.dart. Defaults to GOOGLE'S OFFICIAL TEST AD UNIT IDs so the
// feature works out of the box in debug builds without any setup — these
// are safe to ship in debug/dev, but MUST be overridden for any build you
// submit to app stores (Google will flag/limit accounts that serve test
// ads in production).
//
// HOW TO BUILD WITH YOUR REAL AD UNIT IDS:
//   flutter build appbundle --release \
//     --dart-define=ADMOB_REWARDED_AD_UNIT_ID_ANDROID=ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx \
//     --dart-define=ADMOB_REWARDED_AD_UNIT_ID_IOS=ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx
//
// You also need your AdMob APP ID (different from the ad unit ID) in
// android/app/src/main/AndroidManifest.xml and ios/Runner/Info.plist —
// see INTEGRATION_GUIDE.md step 2, this can't be set via dart-define
// because the OS reads it before Dart code ever runs.

import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;

class AdConfig {
  AdConfig._();

  // Google's official rewarded-ad TEST unit IDs — see
  // https://developers.google.com/admob/flutter/test-ads
  static const _testRewardedAndroid = 'ca-app-pub-3940256099942544/5224354917';
  static const _testRewardedIOS = 'ca-app-pub-3940256099942544/1712485313';

  static const String rewardedAdUnitIdAndroid = String.fromEnvironment(
    'ADMOB_REWARDED_AD_UNIT_ID_ANDROID',
    defaultValue: _testRewardedAndroid,
  );

  static const String rewardedAdUnitIdIOS = String.fromEnvironment(
    'ADMOB_REWARDED_AD_UNIT_ID_IOS',
    defaultValue: _testRewardedIOS,
  );

  /// The ad unit ID for the current platform. Rewarded ads are mobile-only
  /// (AdMob doesn't serve to Flutter web) — callers should check
  /// [isSupported] first, same way payment_service.dart branches on kIsWeb.
  static String get rewardedAdUnitId {
    if (kIsWeb) return '';
    return Platform.isIOS ? rewardedAdUnitIdIOS : rewardedAdUnitIdAndroid;
  }

  static bool get isSupported => !kIsWeb && (Platform.isAndroid || Platform.isIOS);

  static bool get isUsingTestAdUnit =>
      rewardedAdUnitId == _testRewardedAndroid || rewardedAdUnitId == _testRewardedIOS;
}
