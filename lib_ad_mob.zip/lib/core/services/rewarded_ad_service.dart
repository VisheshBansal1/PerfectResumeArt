// lib/core/services/rewarded_ad_service.dart
//
// Thin, focused wrapper around AdMob's RewardedAd lifecycle. No business
// logic about premium/unlock status lives here — that's PremiumService's
// job. This class only knows how to load, show, and reload an ad.

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'ad_config.dart';

enum RewardedAdLoadState { notLoaded, loading, loaded, failed }

class RewardedAdService {
  RewardedAd? _rewardedAd;
  RewardedAdLoadState _state = RewardedAdLoadState.notLoaded;
  int _loadAttempts = 0;
  static const int _maxLoadAttempts = 3;

  // RewardedAd.load()'s own returned Future completes once the platform
  // call is dispatched — NOT once onAdLoaded/onAdFailedToLoad has actually
  // fired. We track the real outcome ourselves so callers (PremiumGuard,
  // the "Watch Ad" button) can reliably `await` a true/false result.
  Completer<bool>? _pendingLoad;

  RewardedAdLoadState get state => _state;

  /// True once an ad has finished loading and is ready to show instantly.
  bool get isReady => _state == RewardedAdLoadState.loaded && _rewardedAd != null;

  // ── Load ─────────────────────────────────────────────────────────────────
  //
  // Call this speculatively (e.g. once on app start, and it's also called
  // automatically after every show/failure) so an ad is USUALLY already
  // warm by the time the user taps "Watch Ad". It's also safe to call
  // on-demand and await the result if no ad happens to be ready yet.
  //
  // Returns true iff an ad is ready to show by the time this completes.
  Future<bool> loadRewardedAd() async {
    if (!AdConfig.isSupported) return false;

    if (isReady) return true; // already have one warm — nothing to do

    if (_state == RewardedAdLoadState.loading && _pendingLoad != null) {
      // A load is already in flight (e.g. called once from main() and
      // again from the dialog before the first finished) — piggyback on
      // it instead of firing a duplicate request.
      return _pendingLoad!.future;
    }

    _state = RewardedAdLoadState.loading;
    final completer = Completer<bool>();
    _pendingLoad = completer;

    await RewardedAd.load(
      adUnitId: AdConfig.rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _state = RewardedAdLoadState.loaded;
          _loadAttempts = 0;
          debugPrint('[RewardedAdService] \u2705 Ad loaded and ready.');
          if (!completer.isCompleted) completer.complete(true);
          _pendingLoad = null;
        },
        onAdFailedToLoad: (LoadAdError error) {
          _rewardedAd = null;
          _state = RewardedAdLoadState.failed;
          _loadAttempts++;
          debugPrint(
            '[RewardedAdService] \u26a0\ufe0f Failed to load (attempt $_loadAttempts/$_maxLoadAttempts): ${error.message}',
          );
          if (!completer.isCompleted) completer.complete(false);
          _pendingLoad = null;
          // Bounded background retry so an ad is likely warm again soon —
          // never hammer AdMob in a tight loop if fill is genuinely
          // unavailable (no internet, no inventory for this user/region).
          if (_loadAttempts < _maxLoadAttempts) {
            Future.delayed(Duration(seconds: 2 * _loadAttempts), loadRewardedAd);
          } else {
            debugPrint('[RewardedAdService] Giving up after $_maxLoadAttempts attempts. '
                'Will retry on next explicit loadRewardedAd() call.');
          }
        },
      ),
    );

    return completer.future;
  }

  // ── Show ─────────────────────────────────────────────────────────────────
  //
  // Returns true ONLY if AdMob's onUserEarnedReward fired before the ad
  // was dismissed — i.e. the user watched it to completion.
  //
  // IMPORTANT: this return value is a UI signal to proceed, not the unlock
  // itself. The caller (PremiumService.unlockPremiumTemporarily) must still
  // call the backend, which is the only thing that actually writes
  // rewardUnlockExpiry. Never unlock premium locally just because this
  // returned true.
  Future<bool> showRewardedAd() async {
    if (!isReady) {
      debugPrint('[RewardedAdService] showRewardedAd() called with no ad ready.');
      return false;
    }

    final ad = _rewardedAd!;
    final completer = Completer<bool>();
    var earnedReward = false;

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdShowedFullScreenContent: (ad) {
        debugPrint('[RewardedAdService] Ad showing.');
      },
      onAdDismissedFullScreenContent: (ad) {
        debugPrint('[RewardedAdService] Ad dismissed (earnedReward=$earnedReward).');
        ad.dispose();
        _rewardedAd = null;
        _state = RewardedAdLoadState.notLoaded;
        if (!completer.isCompleted) completer.complete(earnedReward);
        loadRewardedAd(); // auto-preload the next one, fire-and-forget
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        debugPrint('[RewardedAdService] \u26a0\ufe0f Failed to show: ${error.message}');
        ad.dispose();
        _rewardedAd = null;
        _state = RewardedAdLoadState.notLoaded;
        if (!completer.isCompleted) completer.complete(false);
        loadRewardedAd();
      },
    );

    try {
      await ad.show(
        onUserEarnedReward: (ad, reward) {
          earnedReward = true;
          debugPrint('[RewardedAdService] \ud83c\udf81 Reward earned: ${reward.amount} ${reward.type}');
        },
      );
    } catch (e) {
      debugPrint('[RewardedAdService] show() threw: $e');
      if (!completer.isCompleted) completer.complete(false);
    }

    return completer.future;
  }

  void dispose() {
    _rewardedAd?.dispose();
    _rewardedAd = null;
    _state = RewardedAdLoadState.notLoaded;
    _pendingLoad = null;
  }
}
