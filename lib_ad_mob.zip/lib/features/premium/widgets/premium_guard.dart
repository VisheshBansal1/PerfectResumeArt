// lib/features/premium/widgets/premium_guard.dart
//
// Call PremiumGuard.run() (or .check()) before opening ANY premium
// screen or action. This is the CLIENT-side gate — it exists purely for
// a good UX (don't even attempt to open the screen if we already know
// it'll be blocked). The AI API itself is protected independently on the
// backend (requirePremiumAccess.js) — never rely on this guard alone for
// security, since a modified client could skip it entirely.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_theme.dart';
import '../../../providers/premium_access_providers.dart';
import 'premium_dialog.dart';

class PremiumGuard {
  PremiumGuard._();

  /// Route-protection check:
  ///   if Premium               -> true
  ///   else if reward unlock active -> true
  ///   else                     -> false (caller should not proceed)
  ///
  /// This does NOT show any UI — use [run] if you want the dialog shown
  /// automatically on denial.
  static Future<bool> check(WidgetRef ref) {
    return ref.read(premiumServiceProvider).canAccessPremium();
  }

  /// The usual entry point: checks access, and if the user doesn't have
  /// it, shows the premium dialog and gives them the chance to unlock
  /// right there. Runs [onAccessGranted] the moment access is confirmed —
  /// either immediately (already had access) or right after the dialog
  /// reports a successful unlock/purchase.
  ///
  /// Usage:
  ///   onPressed: () => PremiumGuard.run(
  ///     context, ref,
  ///     featureName: 'Fix My Resume',
  ///     onAccessGranted: () => Navigator.push(context, ...),
  ///   ),
  static Future<void> run(
    BuildContext context,
    WidgetRef ref, {
    String? featureName,
    required VoidCallback onAccessGranted,
  }) async {
    final hasAccess = await check(ref);
    if (hasAccess) {
      onAccessGranted();
      return;
    }
    if (!context.mounted) return;
    final unlocked = await showPremiumDialog(context, featureName: featureName);
    if (unlocked) onAccessGranted();
  }
}

// ─── Countdown Timer (bonus feature) ───────────────────────────────────────
//
// "Premium unlocked for 29m 15s" — ticks every second while a reward
// unlock is active; disappears and fires onExpired() once when it ends,
// so premium features re-lock automatically without the user needing to
// do anything.
//
// Drop this anywhere useful — e.g. pinned at the top of a premium screen,
// or in premium_hub_screen.dart / the app bar while a tool is in use.
class PremiumCountdownBadge extends ConsumerStatefulWidget {
  final VoidCallback? onExpired;
  const PremiumCountdownBadge({super.key, this.onExpired});

  @override
  ConsumerState<PremiumCountdownBadge> createState() => _PremiumCountdownBadgeState();
}

class _PremiumCountdownBadgeState extends ConsumerState<PremiumCountdownBadge> {
  Timer? _ticker;
  bool _wasActive = false;

  @override
  void initState() {
    super.initState();
    // Firestore only emits when the document actually changes, so this
    // local 1s ticker is what makes the "29m 15s" text count down smoothly
    // in between — the expiry timestamp itself still comes from Firestore.
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final status = ref.watch(premiumStatusStreamProvider).value;
    final isActive = status?.isRewardUnlockActive ?? false;

    if (_wasActive && !isActive) {
      // Just expired since the last build — notify once, after this frame
      // (never call a callback that might rebuild the tree mid-build).
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) widget.onExpired?.call();
      });
    }
    _wasActive = isActive;

    if (!isActive || status == null) return const SizedBox.shrink();
    if (status.isPremiumActive) return const SizedBox.shrink(); // real premium never shows a countdown

    final remaining = status.remainingUnlockTime;
    final minutes = remaining.inMinutes;
    final seconds = remaining.inSeconds % 60;
    final isRunningLow = remaining.inMinutes < 5;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: (isRunningLow ? AppTheme.warning : AppTheme.accent).withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: (isRunningLow ? AppTheme.warning : AppTheme.accent).withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.bolt_rounded,
            size: 15,
            color: isRunningLow ? AppTheme.warning : AppTheme.accent,
          ),
          const SizedBox(width: 5),
          Text(
            'Premium unlocked for ${minutes}m ${seconds.toString().padLeft(2, '0')}s',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: isRunningLow ? AppTheme.warning : AppTheme.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
