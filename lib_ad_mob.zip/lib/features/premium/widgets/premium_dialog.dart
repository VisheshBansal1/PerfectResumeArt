// lib/features/premium/widgets/premium_dialog.dart
//
// The bottom sheet shown whenever a free user taps a premium feature
// without access. Pure UI + local flow-state — all the actual unlock
// logic lives in premium_access_providers.dart / premium_service.dart.
//
// Usage (typically you won't call this directly — see PremiumGuard):
//   final unlocked = await showPremiumDialog(context);
//   if (unlocked) { /* proceed to the feature */ }

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb_auth;

import '../../../core/constants/app_theme.dart';
import '../../../core/services/payment_service.dart';
import '../../../models/premium_status.dart';
import '../../../providers/premium_access_providers.dart';

/// Shows the premium bottom sheet. Returns true if the user gained access
/// before the sheet closed (either via a rewarded-ad unlock, or by
/// completing a purchase) — false if they dismissed it without unlocking.
Future<bool> showPremiumDialog(BuildContext context, {String? featureName}) async {
  final result = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => PremiumDialog(featureName: featureName),
  );
  return result ?? false;
}

class PremiumDialog extends ConsumerStatefulWidget {
  final String? featureName;
  const PremiumDialog({super.key, this.featureName});

  @override
  ConsumerState<PremiumDialog> createState() => _PremiumDialogState();
}

class _PremiumDialogState extends ConsumerState<PremiumDialog> {
  bool _purchaseInFlight = false;

  Future<void> _watchAd() async {
    final notifier = ref.read(rewardUnlockProvider.notifier);
    await notifier.watchAdToUnlock();
    if (!mounted) return;
    if (ref.read(rewardUnlockProvider).phase == RewardUnlockPhase.success) {
      // Brief success flash so the user sees confirmation, then close.
      await Future.delayed(const Duration(milliseconds: 900));
      if (mounted) Navigator.of(context).pop(true);
    }
  }

  Future<void> _buyPremium() async {
    final user = FirebaseAuthCurrentUser.emailAndName();
    setState(() => _purchaseInFlight = true);
    // Close this sheet first — stacking two bottom sheets is bad UX — then
    // hand off to the app's existing Razorpay paywall for the Bundle plan
    // (closest existing match to "unlimited access, no ads"). See
    // INTEGRATION_GUIDE.md for how to also flip `isPremium: true` server
    // side when this purchase completes.
    Navigator.of(context).pop(false);
    final success = await PaywallSheet.show(
      context,
      plan: PaymentPlan.bundle,
      userEmail: user.email,
      userName: user.name,
    );
    if (success) {
      // The purchase succeeded — nothing else to do here; if the backend
      // hook described in the guide is wired up, premiumStatusStreamProvider
      // will reflect isPremium:true automatically via the Firestore listener.
      debugPrint('[PremiumDialog] Purchase completed.');
    }
    if (mounted) setState(() => _purchaseInFlight = false);
  }

  @override
  Widget build(BuildContext context) {
    final unlockState = ref.watch(rewardUnlockProvider);
    final statusAsync = ref.watch(premiumStatusStreamProvider);
    final status = statusAsync.value ?? const PremiumStatus();

    final weeklyRemaining = status.weeklyRemaining;
    final weeklyLimit = PremiumStatus.weeklyLimit;
    final atWeeklyLimit = weeklyRemaining <= 0;

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(
            color: AppTheme.cardLight,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          padding: const EdgeInsets.fromLTRB(24, 14, 24, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.borderLight,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // ── Header ──────────────────────────────────────────────────
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppTheme.primary, AppTheme.primaryDark],
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Unlock Premium Feature',
                          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700, color: AppTheme.textPrimary),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Choose how you want to continue.',
                          style: TextStyle(fontSize: 13.5, color: AppTheme.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),
              WeeklyRewardTokensBadge(remaining: weeklyRemaining, limit: weeklyLimit),
              const SizedBox(height: 18),

              // ── Inline error / status banner ───────────────────────────
              if (unlockState.errorMessage != null && unlockState.phase == RewardUnlockPhase.failed)
                _ErrorBanner(message: unlockState.errorMessage!, isWarning: unlockState.isWeeklyLimitReached),
              if (unlockState.phase == RewardUnlockPhase.success)
                const _SuccessBanner(),

              if (unlockState.errorMessage != null || unlockState.phase == RewardUnlockPhase.success)
                const SizedBox(height: 14),

              // ── Option 1: Watch Rewarded Ad ────────────────────────────
              _PremiumOptionCard(
                icon: '\ud83c\udf81',
                title: 'Watch Rewarded Ad',
                description: 'Unlock premium AI features temporarily.',
                enabled: !atWeeklyLimit && !unlockState.isBusy,
                isLoading: unlockState.isBusy,
                loadingLabel: switch (unlockState.phase) {
                  RewardUnlockPhase.loadingAd => 'Loading ad\u2026',
                  RewardUnlockPhase.showingAd => 'Playing ad\u2026',
                  RewardUnlockPhase.verifying => 'Verifying\u2026',
                  _ => null,
                },
                onTap: _watchAd,
              ),
              const SizedBox(height: 12),

              // ── Option 2: Buy Premium ──────────────────────────────────
              _PremiumOptionCard(
                icon: '\ud83d\udc51',
                title: 'Buy Premium',
                description: 'Unlimited access.\nNo Rewarded Ads.\nPriority AI processing.',
                enabled: !_purchaseInFlight,
                isLoading: _purchaseInFlight,
                loadingLabel: _purchaseInFlight ? 'Opening checkout\u2026' : null,
                gradient: const LinearGradient(
                  colors: [AppTheme.primary, AppTheme.primaryDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: _buyPremium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Weekly Reward Tokens Badge ─────────────────────────────────────────────
//
// "🎁 Weekly Reward Tokens  ⭐⭐⭐ 3/3 Available" / "⭐☆☆ 1/3 Remaining"
// Exposed publicly so it can also be dropped into premium_hub_screen.dart
// or a profile screen if useful there.
class WeeklyRewardTokensBadge extends StatelessWidget {
  final int remaining;
  final int limit;
  const WeeklyRewardTokensBadge({super.key, required this.remaining, required this.limit});

  @override
  Widget build(BuildContext context) {
    final allAvailable = remaining >= limit;
    final none = remaining <= 0;
    final stars = List.generate(
      limit,
      (i) => i < remaining ? '\u2b50' : '\u2606',
    ).join();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: none ? AppTheme.error.withOpacity(0.06) : AppTheme.accent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: none ? AppTheme.error.withOpacity(0.2) : AppTheme.accent.withOpacity(0.25)),
      ),
      child: Row(
        children: [
          const Text('\ud83c\udf81', style: TextStyle(fontSize: 16)),
          const SizedBox(width: 8),
          const Text(
            'Weekly Reward Tokens',
            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppTheme.textPrimary),
          ),
          const Spacer(),
          Text(stars, style: const TextStyle(fontSize: 13, letterSpacing: 1)),
          const SizedBox(width: 6),
          Text(
            '$remaining/$limit ${allAvailable ? 'Available' : 'Remaining'}',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: none ? AppTheme.error : AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Option Card ─────────────────────────────────────────────────────────────

class _PremiumOptionCard extends StatelessWidget {
  final String icon;
  final String title;
  final String description;
  final bool enabled;
  final bool isLoading;
  final String? loadingLabel;
  final Gradient? gradient;
  final VoidCallback onTap;

  const _PremiumOptionCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.enabled,
    required this.isLoading,
    required this.onTap,
    this.loadingLabel,
    this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    final isGradient = gradient != null;
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: enabled ? onTap : null,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: isGradient ? gradient : null,
            color: isGradient ? null : AppTheme.surfaceLight,
            borderRadius: BorderRadius.circular(16),
            border: isGradient ? null : Border.all(color: AppTheme.borderLight),
          ),
          child: Opacity(
            opacity: enabled ? 1 : 0.55,
            child: Row(
              children: [
                Text(icon, style: const TextStyle(fontSize: 26)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 15.5,
                          fontWeight: FontWeight.w700,
                          color: isGradient ? Colors.white : AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        isLoading && loadingLabel != null ? loadingLabel! : description,
                        style: TextStyle(
                          fontSize: 12.5,
                          height: 1.35,
                          color: isGradient ? Colors.white.withOpacity(0.92) : AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                if (isLoading)
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.4,
                      valueColor: AlwaysStoppedAnimation(isGradient ? Colors.white : AppTheme.primary),
                    ),
                  )
                else
                  Icon(
                    Icons.chevron_right_rounded,
                    color: isGradient ? Colors.white : AppTheme.textSecondary,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Banners ──────────────────────────────────────────────────────────────

class _ErrorBanner extends StatelessWidget {
  final String message;
  final bool isWarning;
  const _ErrorBanner({required this.message, required this.isWarning});

  @override
  Widget build(BuildContext context) {
    final color = isWarning ? AppTheme.warning : AppTheme.error;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(isWarning ? Icons.info_outline_rounded : Icons.error_outline_rounded, color: color, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(message, style: TextStyle(fontSize: 12.5, height: 1.4, color: AppTheme.textPrimary)),
          ),
        ],
      ),
    );
  }
}

class _SuccessBanner extends StatelessWidget {
  const _SuccessBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.success.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.success.withOpacity(0.25)),
      ),
      child: const Row(
        children: [
          Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 18),
          SizedBox(width: 8),
          Text(
            'Unlocked! Premium features are now available.',
            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppTheme.textPrimary),
          ),
        ],
      ),
    );
  }
}

// ─── Small helper ─────────────────────────────────────────────────────────

class FirebaseAuthCurrentUser {
  final String email;
  final String name;
  const FirebaseAuthCurrentUser._(this.email, this.name);

  factory FirebaseAuthCurrentUser.emailAndName() {
    final user = fb_auth.FirebaseAuth.instance.currentUser;
    return FirebaseAuthCurrentUser._(user?.email ?? '', user?.displayName ?? 'User');
  }
}

// ─── Watch-Ad-To-Unlock Button ─────────────────────────────────────────────
//
// Drop this next to a screen's existing paid "Unlock" button (see
// fix_resume_screen.dart / jd_optimize_screen.dart / resume_generator_screen.dart
// for real usage) — it's the free alternative, styled as a secondary action
// so it doesn't compete with the paid CTA. Opens the same premium dialog
// used everywhere else; calls [onUnlocked] only if the user actually
// gains access (ad watched to completion, or they buy from inside the
// dialog) — never on dismissal.
class WatchAdToUnlockButton extends StatelessWidget {
  final String featureName;
  final VoidCallback onUnlocked;
  // For screens with a precondition (e.g. jd_optimize_screen.dart requires
  // a pasted job description first) — mirrors how their paid button is
  // already disabled via `onPressed: condition ? null : ...` so the ad
  // isn't spent on a request that would just fail validation afterward.
  final bool enabled;

  const WatchAdToUnlockButton({
    super.key,
    required this.featureName,
    required this.onUnlocked,
    this.enabled = true,
  });

  Future<void> _tap(BuildContext context) async {
    final unlocked = await showPremiumDialog(context, featureName: featureName);
    if (unlocked) onUnlocked();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: OutlinedButton(
        onPressed: enabled ? () => _tap(context) : null,
        style: OutlinedButton.styleFrom(
          foregroundColor: AppTheme.accent,
          side: BorderSide(color: AppTheme.accent.withOpacity(0.45)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          disabledForegroundColor: AppTheme.textSecondary.withOpacity(0.4),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('\ud83c\udf81', style: TextStyle(fontSize: 15)),
            SizedBox(width: 8),
            Text(
              'Or watch an ad to unlock free',
              style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}
