import 'package:cloud_firestore/cloud_firestore.dart';

/// Read-only view of a user's premium + reward-unlock status, built from
/// the `users/{uid}` Firestore document.
///
/// This mirrors the backend's `premiumService.js#computeStatus()` — that
/// file is the AUTHORITATIVE version enforced on every AI call. This model
/// exists purely so the Flutter UI can react instantly to Firestore's
/// real-time sync (countdown timers, the weekly-token badge) without a
/// network round trip. Never trust this model for anything security
/// sensitive; it is a display projection, not a source of truth.
///
/// None of these fields are ever written by the client — see
/// PremiumService and firestore.rules.
class PremiumStatus {
  final bool isPremiumFlag;
  final DateTime? premiumExpiry;
  final DateTime? rewardUnlockExpiry;
  final int weeklyRewardCount;
  final DateTime? lastRewardReset;

  const PremiumStatus({
    this.isPremiumFlag = false,
    this.premiumExpiry,
    this.rewardUnlockExpiry,
    this.weeklyRewardCount = 0,
    this.lastRewardReset,
  });

  /// A brand-new/never-purchased user reads exactly like this — every
  /// field is optional on the document, so there is nothing to migrate.
  factory PremiumStatus.fromMap(Map<String, dynamic> map) {
    return PremiumStatus(
      isPremiumFlag: map['isPremium'] as bool? ?? false,
      premiumExpiry: _toDateTime(map['premiumExpiry']),
      rewardUnlockExpiry: _toDateTime(map['rewardUnlockExpiry']),
      weeklyRewardCount: (map['weeklyRewardCount'] as num?)?.toInt() ?? 0,
      lastRewardReset: _toDateTime(map['lastRewardReset']),
    );
  }

  static DateTime? _toDateTime(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    return null;
  }

  // Must match WEEKLY_REWARD_LIMIT / RESET_WINDOW_MS in the backend's
  // src/config/premiumConfig.js. Kept here only so the UI can render
  // correctly before the first network round trip; the backend's copy of
  // these numbers is the one actually enforced. If you retune the backend,
  // update these two to match so the UI doesn't show a stale limit.
  static const int weeklyLimit = 3;
  static const Duration resetWindow = Duration(days: 7);
  static const Duration defaultUnlockDuration = Duration(minutes: 30);

  /// True if the user has a live premium subscription/bundle — a null
  /// [premiumExpiry] with [isPremiumFlag] true means lifetime premium.
  bool get isPremiumActive =>
      isPremiumFlag &&
      (premiumExpiry == null || premiumExpiry!.isAfter(DateTime.now()));

  /// True if a rewarded-ad unlock is currently in effect.
  bool get isRewardUnlockActive =>
      rewardUnlockExpiry != null && rewardUnlockExpiry!.isAfter(DateTime.now());

  /// The single check every premium screen/action should gate on.
  bool get canAccessPremium => isPremiumActive || isRewardUnlockActive;

  /// Time left on the current ad-granted unlock. Zero when inactive.
  Duration get remainingUnlockTime {
    if (!isRewardUnlockActive) return Duration.zero;
    return rewardUnlockExpiry!.difference(DateTime.now());
  }

  bool get _needsWeeklyReset {
    if (lastRewardReset == null) return true;
    return DateTime.now().difference(lastRewardReset!) >= resetWindow;
  }

  /// Unlocks used in the CURRENT window, applying the rolling reset even
  /// though nothing has been written to Firestore yet (the backend only
  /// persists a reset at the moment it actually grants the next unlock).
  int get effectiveWeeklyCount => _needsWeeklyReset ? 0 : weeklyRewardCount;

  int get weeklyRemaining =>
      (weeklyLimit - effectiveWeeklyCount).clamp(0, weeklyLimit);

  bool get hasWeeklyUnlocksRemaining => weeklyRemaining > 0;

  /// When the window rolls over next, for a "resets in 3 days" label.
  /// Null once the window has already elapsed (i.e. it would reset NOW,
  /// on next use, rather than at some future point).
  DateTime? get nextWeeklyResetAt {
    if (_needsWeeklyReset || lastRewardReset == null) return null;
    return lastRewardReset!.add(resetWindow);
  }
}
