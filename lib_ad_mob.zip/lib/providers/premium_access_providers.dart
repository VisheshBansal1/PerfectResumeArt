// lib/providers/premium_access_providers.dart
//
// Riverpod wiring for the hybrid monetization system. Reuses the existing
// firebaseServiceProvider from auth_provider.dart rather than creating a
// second FirebaseFirestore-backed instance.

import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/services/premium_service.dart';
import '../core/services/rewarded_ad_service.dart';
import '../features/auth/providers/auth_provider.dart' show firebaseServiceProvider;
import '../models/premium_status.dart';

// ─── Service Providers ────────────────────────────────────────────────────

final premiumServiceProvider = Provider<PremiumService>(
  (ref) => PremiumService(ref.read(firebaseServiceProvider)),
);

// One RewardedAdService for the app's lifetime — keeps an ad warm so the
// premium dialog's "Watch Ad" button can show instantly instead of loading
// on tap. Kick off the first load as soon as the provider is created;
// call ref.read(rewardedAdServiceProvider) once early (e.g. in main() or
// your root widget's initState) so that first load starts before the user
// ever opens the dialog.
final rewardedAdServiceProvider = Provider<RewardedAdService>((ref) {
  final service = RewardedAdService();
  service.loadRewardedAd();
  ref.onDispose(service.dispose);
  return service;
});

// ─── Live Status Stream ───────────────────────────────────────────────────
//
// Watch this from any widget that needs to react to premium/unlock status
// in real time — the countdown timer, the weekly-token badge, route
// guards. Backed by a Firestore snapshot listener, so it updates the
// instant the backend's unlock-reward write lands, with no manual refresh.
final premiumStatusStreamProvider = StreamProvider<PremiumStatus>((ref) {
  return ref.watch(premiumServiceProvider).statusStream();
});

// ─── Reward Unlock Flow State ─────────────────────────────────────────────
//
// Drives the "Watch Rewarded Ad" button end-to-end: load (if needed) →
// show → verify with backend → success/failure. Mirrors the
// isLoading/error state-notifier pattern already used throughout
// premium_providers.dart (FixResumeState, JdOptimizeState, etc).

enum RewardUnlockPhase { idle, loadingAd, showingAd, verifying, success, failed }

class RewardUnlockState {
  final RewardUnlockPhase phase;
  final String? errorMessage;
  final bool isWeeklyLimitReached;

  const RewardUnlockState({
    this.phase = RewardUnlockPhase.idle,
    this.errorMessage,
    this.isWeeklyLimitReached = false,
  });

  bool get isBusy =>
      phase == RewardUnlockPhase.loadingAd ||
      phase == RewardUnlockPhase.showingAd ||
      phase == RewardUnlockPhase.verifying;
}

class RewardUnlockNotifier extends StateNotifier<RewardUnlockState> {
  RewardUnlockNotifier(this._adService, this._premiumService)
      : super(const RewardUnlockState());

  final RewardedAdService _adService;
  final PremiumService _premiumService;

  Future<void> watchAdToUnlock() async {
    state = const RewardUnlockState(phase: RewardUnlockPhase.loadingAd);

    final ready = _adService.isReady || await _adService.loadRewardedAd();
    if (!ready) {
      state = const RewardUnlockState(
        phase: RewardUnlockPhase.failed,
        errorMessage:
            'No rewarded ad available currently.\n\nPlease try again later or purchase Premium.',
      );
      return;
    }

    state = state.copyWithPhase(RewardUnlockPhase.showingAd);
    final earnedReward = await _adService.showRewardedAd();
    if (!earnedReward) {
      state = const RewardUnlockState(
        phase: RewardUnlockPhase.failed,
        errorMessage:
            'The ad was closed before finishing. Watch the full ad to unlock premium features.',
      );
      return;
    }

    state = state.copyWithPhase(RewardUnlockPhase.verifying);
    try {
      await _premiumService.unlockPremiumTemporarily();
      state = const RewardUnlockState(phase: RewardUnlockPhase.success);
    } on PremiumUnlockException catch (e) {
      state = RewardUnlockState(
        phase: RewardUnlockPhase.failed,
        errorMessage: e.message,
        isWeeklyLimitReached: e.code == PremiumUnlockErrorCode.weeklyLimitReached,
      );
    } catch (_) {
      state = const RewardUnlockState(
        phase: RewardUnlockPhase.failed,
        errorMessage: 'Something went wrong. Please try again.',
      );
    }
  }

  void reset() => state = const RewardUnlockState();
}

extension on RewardUnlockState {
  RewardUnlockState copyWithPhase(RewardUnlockPhase phase) => RewardUnlockState(
        phase: phase,
        errorMessage: errorMessage,
        isWeeklyLimitReached: isWeeklyLimitReached,
      );
}

final rewardUnlockProvider =
    StateNotifierProvider.autoDispose<RewardUnlockNotifier, RewardUnlockState>((ref) {
  return RewardUnlockNotifier(
    ref.read(rewardedAdServiceProvider),
    ref.read(premiumServiceProvider),
  );
});
