import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart' show Color;
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:open_file/open_file.dart';
import 'package:share_plus/share_plus.dart';
import 'resume_pdf_web.dart'
    if (dart.library.io) 'resume_pdf_stub.dart'
    as web_dl;

// ─────────────────────────────────────────────────────────────────────────
// RESUME TEMPLATES
//
// Every template reuses the exact same proven text-parsing layout logic
// (_buildPage below) — only color, header treatment, and bullet style
// change. This keeps rendering behavior well-tested while still giving a
// genuinely different visual identity per template.
// ─────────────────────────────────────────────────────────────────────────

enum ResumeBulletStyle { dot, dash, square }

class ResumeTemplateStyle {
  final String id;
  final String name;
  final String description;
  final String nameHex;
  final String accentHex;
  final String secondaryHex;
  final String bodyHex;
  final double headerLetterSpacing;
  final double dividerThicknessThin;
  final double dividerThicknessBold;
  final double nameFontSize;
  final ResumeBulletStyle bulletStyle;

  const ResumeTemplateStyle({
    required this.id,
    required this.name,
    required this.description,
    required this.nameHex,
    required this.accentHex,
    required this.secondaryHex,
    required this.bodyHex,
    this.headerLetterSpacing = 1.2,
    this.dividerThicknessThin = 0.6,
    this.dividerThicknessBold = 1.5,
    this.nameFontSize = 22,
    this.bulletStyle = ResumeBulletStyle.dot,
  });

  PdfColor get namePdf => PdfColor.fromHex(nameHex);
  PdfColor get accentPdf => PdfColor.fromHex(accentHex);
  PdfColor get secondaryPdf => PdfColor.fromHex(secondaryHex);
  PdfColor get bodyPdf => PdfColor.fromHex(bodyHex);

  /// For UI swatches/previews in the template picker (Flutter Color, not PdfColor).
  Color get accentFlutterColor => Color(int.parse('FF$accentHex', radix: 16));
  Color get nameFlutterColor => Color(int.parse('FF$nameHex', radix: 16));
}

class ResumeTemplates {
  ResumeTemplates._();

  static const classicBlue = ResumeTemplateStyle(
    id: 'classic_blue',
    name: 'Classic Blue',
    description: 'Clean and professional — safe for any role or industry',
    nameHex: '1A1A2E',
    accentHex: '2D5BE3',
    secondaryHex: '6B7280',
    bodyHex: '111827',
    headerLetterSpacing: 1.2,
    dividerThicknessThin: 0.6,
    dividerThicknessBold: 1.5,
    nameFontSize: 22,
    bulletStyle: ResumeBulletStyle.dot,
  );

  static const modernTeal = ResumeTemplateStyle(
    id: 'modern_teal',
    name: 'Modern Teal',
    description: 'Confident and current — great for tech and product roles',
    nameHex: '0F172A',
    accentHex: '0D9488',
    secondaryHex: '64748B',
    bodyHex: '111827',
    headerLetterSpacing: 1.5,
    dividerThicknessThin: 0.8,
    dividerThicknessBold: 1.8,
    nameFontSize: 23,
    bulletStyle: ResumeBulletStyle.square,
  );

  static const minimalistMono = ResumeTemplateStyle(
    id: 'minimalist_mono',
    name: 'Minimalist',
    description: 'Understated black & white — lets the content speak',
    nameHex: '000000',
    accentHex: '374151',
    secondaryHex: '6B7280',
    bodyHex: '1F2937',
    headerLetterSpacing: 2.0,
    dividerThicknessThin: 0.4,
    dividerThicknessBold: 0.8,
    nameFontSize: 20,
    bulletStyle: ResumeBulletStyle.dash,
  );

  static const boldViolet = ResumeTemplateStyle(
    id: 'bold_violet',
    name: 'Bold Violet',
    description: 'Distinctive accent — for startup, design, and creative-tech roles',
    nameHex: '1E1B2E',
    accentHex: '7C3AED',
    secondaryHex: '6B7280',
    bodyHex: '111827',
    headerLetterSpacing: 1.3,
    dividerThicknessThin: 0.8,
    dividerThicknessBold: 2.0,
    nameFontSize: 24,
    bulletStyle: ResumeBulletStyle.square,
  );

  static const elegantMaroon = ResumeTemplateStyle(
    id: 'elegant_maroon',
    name: 'Elegant Maroon',
    description: 'Refined and traditional — for business, finance, and legal roles',
    nameHex: '1F1315',
    accentHex: '9F1239',
    secondaryHex: '78716C',
    bodyHex: '1C1917',
    headerLetterSpacing: 1.0,
    dividerThicknessThin: 0.6,
    dividerThicknessBold: 1.5,
    nameFontSize: 22,
    bulletStyle: ResumeBulletStyle.dot,
  );

  static const all = [classicBlue, modernTeal, minimalistMono, boldViolet, elegantMaroon];

  static ResumeTemplateStyle byId(String id) =>
      all.firstWhere((t) => t.id == id, orElse: () => classicBlue);

  /// Picks a sensible default template from resume content when the user
  /// hasn't chosen one explicitly — a starting point, not a locked-in
  /// choice, since the picker always lets them switch.
  static ResumeTemplateStyle autoDetect(String resumeText) {
    final lower = resumeText.toLowerCase();

    int score(List<String> keywords) =>
        keywords.where((k) => lower.contains(k)).length;

    final techScore = score(const [
      'flutter', 'android', 'ios', 'react', 'developer', 'engineer', 'software',
      'backend', 'frontend', 'full stack', 'devops', 'cloud computing', 'python',
      'java ', 'kotlin', 'swift', 'rest api', 'database', 'sql', 'machine learning',
      'data scientist', 'programming', 'github', 'kubernetes', 'docker', 'aws',
    ]);
    final businessScore = score(const [
      'finance', 'accounting', 'banking', 'sales', 'marketing', 'business analyst',
      'consultant', 'operations manager', 'mba', 'hr ', 'human resources', 'legal',
      'audit', 'stakeholder management', 'p&l', 'financial analysis', 'compliance',
    ]);
    final designScore = score(const [
      'ux design', 'ui design', 'graphic design', 'product design', 'figma',
      'adobe', 'creative director', 'visual design', 'user research', 'prototyping',
    ]);

    if (designScore > 0 && designScore >= techScore && designScore >= businessScore) {
      return boldViolet;
    }
    if (businessScore > techScore) return elegantMaroon;
    if (techScore > 0) return modernTeal;
    return classicBlue;
  }
}

class ResumePdfService {
  static pw.Font? _regular;
  static pw.Font? _bold;
  static pw.Font? _italic;

  /// Downloads Roboto fonts from reliable Google Fonts CDN with fallback URLs.
  static Future<void> _loadFonts() async {
    if (_regular != null && _bold != null) return;

    // Primary: google/fonts repo (stable, well-known path)
    // Fallback: googlefonts/roboto repo alternate path
    final regularUrls = [
      'https://github.com/google/fonts/raw/main/apache/roboto/static/Roboto-Regular.ttf',
      'https://github.com/googlefonts/roboto-2/raw/main/src/hinted-base/Roboto-Regular.ttf',
    ];
    final boldUrls = [
      'https://github.com/google/fonts/raw/main/apache/roboto/static/Roboto-Bold.ttf',
      'https://github.com/googlefonts/roboto-2/raw/main/src/hinted-base/Roboto-Bold.ttf',
    ];
    final italicUrls = [
      'https://github.com/google/fonts/raw/main/apache/roboto/static/Roboto-Italic.ttf',
    ];

    Future<Uint8List?> tryDownload(List<String> urls) async {
      for (final url in urls) {
        try {
          final res = await http
              .get(Uri.parse(url))
              .timeout(const Duration(seconds: 10));
          if (res.statusCode == 200 && res.bodyBytes.length > 10000) {
            return res.bodyBytes;
          }
        } catch (_) {
          continue;
        }
      }
      return null;
    }

    final regBytes = await tryDownload(regularUrls);
    final boldBytes = await tryDownload(boldUrls);
    final itaBytes = await tryDownload(italicUrls);

    if (regBytes != null) _regular = pw.Font.ttf(regBytes.buffer.asByteData());
    if (boldBytes != null) _bold = pw.Font.ttf(boldBytes.buffer.asByteData());
    if (itaBytes != null) _italic = pw.Font.ttf(itaBytes.buffer.asByteData());
  }

  Future<String> generatePdf({
    required String resumeText,
    required String fileName,
    ResumeTemplateStyle? template,
  }) async {
    await _loadFonts();
    final style = template ?? ResumeTemplates.autoDetect(resumeText);

    // Normalise smart punctuation regardless of font availability
    final safe = resumeText
        .replaceAll('\u2013', '-') // en-dash
        .replaceAll('\u2014', '--') // em-dash
        .replaceAll('\u20b9', 'Rs.') // ₹
        .replaceAll('\u2019', "'") // curly apostrophe
        .replaceAll('\u201c', '"')
        .replaceAll('\u201d', '"'); // curly quotes
    // NOTE: we intentionally do NOT strip \u2022 (bullet •) here anymore.
    // _buildPage handles it directly so the bullet glyph in the PDF
    // always comes from _bulletChar() which is font-safe.

    final theme = _regular != null
        ? pw.ThemeData.withFont(
            base: _regular!,
            bold: _bold ?? _regular!,
            italic: _italic ?? _regular!,
            boldItalic: _bold ?? _regular!,
          )
        : pw.ThemeData();

    final pdf = pw.Document(theme: theme);
    final lines = safe.split('\n');

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.symmetric(horizontal: 44, vertical: 50),
        build: (ctx) => _buildPage(lines, style),
      ),
    );

    final bytes = await pdf.save();

    if (kIsWeb) {
      web_dl.downloadPdfOnWeb(bytes, '$fileName.pdf');
      return '$fileName.pdf';
    } else {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/$fileName.pdf');
      await file.writeAsBytes(bytes);
      return file.path;
    }
  }

  /// Returns a bullet string that is safe for the current font and matches
  /// the template's bullet style.
  /// When Roboto loaded successfully → the template's glyph
  /// When only Helvetica is available → plain hyphen-minus (ASCII, always works)
  String _bulletChar(ResumeTemplateStyle style) {
    if (_regular == null) return '-  ';
    switch (style.bulletStyle) {
      case ResumeBulletStyle.dot:
        return '\u2022  ';
      case ResumeBulletStyle.dash:
        return '\u2013  ';
      case ResumeBulletStyle.square:
        return '\u25aa  ';
    }
  }

  List<pw.Widget> _buildPage(List<String> lines, ResumeTemplateStyle style) {
    final widgets = <pw.Widget>[];
    bool nameWritten = false;
    bool contactWritten = false;
    bool firstSection = true;

    for (final rawLine in lines) {
      final line = rawLine.trimRight();
      if (line.isEmpty) {
        widgets.add(pw.SizedBox(height: 4));
        continue;
      }

      // ── Candidate name (first non-empty line) ─────────────────────────────
      if (!nameWritten) {
        nameWritten = true;
        widgets.add(
          pw.Text(
            line,
            style: pw.TextStyle(
              fontSize: style.nameFontSize,
              fontWeight: pw.FontWeight.bold,
              color: style.namePdf,
            ),
          ),
        );
        continue;
      }

      // ── Contact line (email / phone / LinkedIn / GitHub) ──────────────────
      if (!contactWritten &&
          (line.contains('@') ||
              line.contains('+91') ||
              line.toLowerCase().contains('github') ||
              line.toLowerCase().contains('linkedin') ||
              (line.contains('|') && line.length < 150))) {
        contactWritten = true;
        widgets.add(pw.SizedBox(height: 2));
        widgets.add(
          pw.Text(
            line,
            style: pw.TextStyle(
              fontSize: 9.5,
              color: style.secondaryPdf,
            ),
          ),
        );
        widgets.add(pw.SizedBox(height: 6));
        widgets.add(
          pw.Divider(color: style.accentPdf, thickness: style.dividerThicknessBold),
        );
        widgets.add(pw.SizedBox(height: 2));
        continue;
      }

      // ── Section headers ────────────────────────────────────────────────────
      if (_isSectionHeader(line)) {
        if (!firstSection) widgets.add(pw.SizedBox(height: 8));
        firstSection = false;
        widgets.add(
          pw.Text(
            line.toUpperCase(),
            style: pw.TextStyle(
              fontSize: 9.5,
              fontWeight: pw.FontWeight.bold,
              color: style.accentPdf,
              letterSpacing: style.headerLetterSpacing,
            ),
          ),
        );
        widgets.add(
          pw.Divider(color: style.accentPdf, thickness: style.dividerThicknessThin),
        );
        widgets.add(pw.SizedBox(height: 3));
        continue;
      }

      // ── Job / project row: "Company | Title | Dates" ──────────────────────
      if (line.contains('|') && !line.contains('@') && !_isBullet(line)) {
        final parts = line.split('|').map((s) => s.trim()).toList();
        widgets.add(pw.SizedBox(height: 5));
        widgets.add(
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Expanded(
                child: pw.Text(
                  parts.take(parts.length - 1).join(' | '),
                  style: pw.TextStyle(
                    fontSize: 10.5,
                    fontWeight: pw.FontWeight.bold,
                    color: style.bodyPdf,
                  ),
                ),
              ),
              pw.Text(
                parts.last,
                style: pw.TextStyle(
                  fontSize: 9.5,
                  color: style.secondaryPdf,
                ),
              ),
            ],
          ),
        );
        continue;
      }

      // ── Bullet points ──────────────────────────────────────────────────────
      if (_isBullet(line)) {
        final stripped = line.trimLeft();
        // Strip leading bullet marker (•, -, *) and any following spaces
        final content = stripped.replaceFirst(RegExp(r'^[•\-\*]\s*'), '');
        widgets.add(
          pw.Padding(
            padding: const pw.EdgeInsets.only(left: 12, top: 2, bottom: 1),
            child: pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  _bulletChar(style),
                  style: pw.TextStyle(
                    fontSize: 10,
                    fontWeight: pw.FontWeight.bold,
                    color: style.accentPdf,
                  ),
                ),
                pw.Expanded(
                  child: pw.Text(
                    content,
                    style: pw.TextStyle(fontSize: 10, lineSpacing: 1.4, color: style.bodyPdf),
                  ),
                ),
              ],
            ),
          ),
        );
        continue;
      }

      // ── Skills line "Label: values" ───────────────────────────────────────
      final colonIdx = line.indexOf(':');
      if (colonIdx > 0 && colonIdx < 35 && !line.startsWith('http')) {
        final label = line.substring(0, colonIdx + 1);
        final value = line.substring(colonIdx + 1).trim();
        widgets.add(
          pw.Padding(
            padding: const pw.EdgeInsets.only(top: 2),
            child: pw.RichText(
              text: pw.TextSpan(
                children: [
                  pw.TextSpan(
                    text: '$label ',
                    style: pw.TextStyle(
                      fontSize: 10,
                      fontWeight: pw.FontWeight.bold,
                      color: style.secondaryPdf,
                    ),
                  ),
                  pw.TextSpan(
                    text: value,
                    style: pw.TextStyle(fontSize: 10, color: style.bodyPdf),
                  ),
                ],
              ),
            ),
          ),
        );
        continue;
      }

      // ── Default plain text ─────────────────────────────────────────────────
      widgets.add(
        pw.Padding(
          padding: const pw.EdgeInsets.only(top: 1),
          child: pw.Text(
            line,
            style: pw.TextStyle(fontSize: 10, lineSpacing: 1.3, color: style.bodyPdf),
          ),
        ),
      );
    }
    return widgets;
  }

  /// True if line starts with a bullet marker (•, -, *)
  bool _isBullet(String line) {
    final s = line.trimLeft();
    return s.startsWith('\u2022') || s.startsWith('- ') || s.startsWith('* ');
  }

  bool _isSectionHeader(String line) {
    final t = line.trim();
    if (t.length < 3 || t.length > 40) return false;
    if (t == t.toUpperCase() && !t.contains('@') && !t.contains('+'))
      return true;
    const known = [
      'Experience',
      'Work Experience',
      'Professional Experience',
      'Education',
      'Skills',
      'Technical Skills',
      'Projects',
      'Summary',
      'Professional Summary',
      'Objective',
      'Certifications',
      'Achievements',
      'Awards',
      'Publications',
      'TECHNICAL SKILLS',
      'WORK EXPERIENCE',
      'PROFESSIONAL SUMMARY',
      'EDUCATION',
      'PROJECTS',
      'EXPERIENCE',
      'CERTIFICATIONS',
    ];
    return known.any((h) => t.toLowerCase() == h.toLowerCase());
  }

  Future<void> openPdf(String path) async {
    if (!kIsWeb) await OpenFile.open(path);
  }

  Future<void> sharePdf(String path, {String subject = 'My Resume'}) async {
    if (!kIsWeb) {
      await Share.shareXFiles([
        XFile(path, mimeType: 'application/pdf'),
      ], subject: subject);
    }
  }
}
