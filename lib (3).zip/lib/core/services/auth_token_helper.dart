import 'package:firebase_auth/firebase_auth.dart';

// ─────────────────────────────────────────────────────────────────────────────
// lib/core/services/auth_token_helper.dart
//
// THE BUG: on Flutter Web, right after a fresh page load, Firebase Auth needs
// a moment to restore a signed-in session from IndexedDB. During that brief
// window, `FirebaseAuth.instance.currentUser` is still null — even for a
// user who IS actually logged in. Every referral/wallet/payment service was
// reading `currentUser` synchronously the instant it needed a token, so a
// screen that loads immediately after a page refresh (Earn & Refer, Profile,
// the home screen's notification badge) could send its very first API call
// with no Authorization header. The backend correctly rejects that as
// unauthenticated, so the dashboard would show an error/empty state even
// though the person was genuinely signed in the whole time.
//
// THE FIX: wait for Firebase's own "I now know the auth state" signal
// (`authStateChanges()`) instead of trusting a snapshot that might be
// mid-restore. If a user is already resolved, this returns instantly —
// it only actually waits during that brief startup window.
// ─────────────────────────────────────────────────────────────────────────────

Future<String?> getIdTokenSafely() async {
  final current = FirebaseAuth.instance.currentUser;
  if (current != null) {
    try {
      return await current.getIdToken();
    } catch (_) {
      return null;
    }
  }

  try {
    final user = await FirebaseAuth.instance
        .authStateChanges()
        .first
        .timeout(const Duration(seconds: 4));
    return await user?.getIdToken();
  } catch (_) {
    return null;
  }
}
