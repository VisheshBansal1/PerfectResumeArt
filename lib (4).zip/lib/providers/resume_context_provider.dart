// lib/providers/resume_context_provider.dart
//
// Single source of truth for the user's current resume.
// Populated when: ATS check runs, Full analysis runs, or manual upload.
// Read by: ALL premium features — no re-upload needed.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../core/services/ai_service.dart';

// ─── State ───────────────────────────────────────────────────────────────────

class ResumeContext {
  /// Full OCR-extracted resume text
  final String text;

  /// Auto-detected job role / target domain (e.g. "Flutter Developer")
  final String detectedRole;

  /// Where this text came from
  final String source; // 'ats' | 'analysis' | 'upload' | 'none'

  const ResumeContext({
    this.text = '',
    this.detectedRole = '',
    this.source = 'none',
  });

  /// True when a real resume is loaded (not empty placeholder)
  bool get hasResume => text.trim().length > 80;

  ResumeContext copyWith({
    String? text,
    String? detectedRole,
    String? source,
  }) =>
      ResumeContext(
        text:         text         ?? this.text,
        detectedRole: detectedRole ?? this.detectedRole,
        source:       source       ?? this.source,
      );
}

// ─── Notifier ─────────────────────────────────────────────────────────────────

class ResumeContextNotifier extends StateNotifier<ResumeContext> {
  ResumeContextNotifier() : super(const ResumeContext());

  /// Call this whenever a resume is extracted (ATS, Analysis, manual upload).
  /// Automatically detects job role from text.
  Future<void> setResume(String extractedText, {required String source}) async {
    if (extractedText.trim().length < 50) return;

    // Set text immediately so features can start using it
    state = state.copyWith(
      text:   extractedText,
      source: source,
    );

    // Detect job role in background
    final role = _detectJobRole(extractedText);
    state = state.copyWith(detectedRole: role);
  }

  /// Simple local job-role detector — no AI call needed, fast.
  /// Looks for common role keywords in the resume text.
  String _detectJobRole(String text) {
    final lower = text.toLowerCase();

    // Order matters — more specific first
    final roles = {
      'flutter developer':        ['flutter', 'dart', 'widget'],
      'android developer':        ['android', 'kotlin', 'java android'],
      'ios developer':            ['swift', 'xcode', 'ios'],
      'full stack developer':     ['full stack', 'fullstack', 'frontend', 'backend'],
      'frontend developer':       ['react', 'vue', 'angular', 'html', 'css', 'javascript'],
      'backend developer':        ['node.js', 'django', 'spring boot', 'express', 'rest api'],
      'data scientist':           ['machine learning', 'data science', 'tensorflow', 'pandas', 'scikit'],
      'data analyst':             ['sql', 'tableau', 'power bi', 'excel', 'data analysis'],
      'devops engineer':          ['docker', 'kubernetes', 'ci/cd', 'jenkins', 'aws devops'],
      'cloud engineer':           ['aws', 'azure', 'gcp', 'cloud', 'terraform'],
      'ml engineer':              ['pytorch', 'keras', 'deep learning', 'nlp', 'computer vision'],
      'software engineer':        ['software engineer', 'software developer', 'programming'],
      'web developer':            ['web', 'html', 'css', 'javascript', 'php'],
      'ui/ux designer':           ['figma', 'ui/ux', 'wireframe', 'prototype', 'adobe xd'],
      'product manager':          ['product manager', 'roadmap', 'agile', 'scrum', 'stakeholder'],
      'cybersecurity engineer':   ['security', 'penetration', 'ethical hacking', 'firewall'],
      'blockchain developer':     ['blockchain', 'solidity', 'web3', 'ethereum', 'smart contract'],
    };

    for (final entry in roles.entries) {
      final keywords = entry.value;
      final matchCount = keywords.where((k) => lower.contains(k)).length;
      if (matchCount >= 1) return entry.key;
    }

    return 'software developer'; // sensible default
  }

  void clear() => state = const ResumeContext();
}

// ─── Provider ─────────────────────────────────────────────────────────────────

final resumeContextProvider =
    StateNotifierProvider<ResumeContextNotifier, ResumeContext>(
  (_) => ResumeContextNotifier(),
);
